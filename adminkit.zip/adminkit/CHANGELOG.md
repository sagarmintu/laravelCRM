# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] 2019-03-21

- Initial release