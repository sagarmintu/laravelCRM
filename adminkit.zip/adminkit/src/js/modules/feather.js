import feather from "feather-icons";

$(function(){
    feather.replace();
});

window.feather = feather;