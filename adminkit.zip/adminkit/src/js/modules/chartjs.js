import Chart from "chart.js";

window.Chart = Chart;
