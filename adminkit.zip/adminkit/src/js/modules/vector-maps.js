import "script-loader!jvectormap-next";
import "script-loader!../vendor/jquery-jvectormap-world-mill.js";
